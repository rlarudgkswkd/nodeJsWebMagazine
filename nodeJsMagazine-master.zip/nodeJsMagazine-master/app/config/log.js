// Winston 모듈을 불러옵니다.
const winston = require('winston');

// 로거를 생성합니다.
const logger = winston.createLogger({
  level: 'info', // 기록할 로그 레벨 (debug, info, warn, error 등)
  format: winston.format.json(), // 로그 형식 (JSON 형태로 기록)
  transports: [
    // 출력 대상 (여기서는 콘솔로 출력)
    new winston.transports.Console()
  ]
});

// 로그 기록 예시
logger.debug('This is a debug message.');
logger.info('This is an info message.');
logger.warn('This is a warning message.');
logger.error('This is an error message.');

module.exports = logger;
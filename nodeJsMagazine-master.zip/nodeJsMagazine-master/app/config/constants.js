// config/constants.js
require('dotenv').config(); // Load environment variables from .env file

// 데이터베이스 관련 상수
exports.DB_HOST = process.env.DB_HOST;
exports.DB_USER = process.env.DB_USER;
exports.DB_PASSWORD = process.env.DB_PASSWORD;
exports.DB_NAME = process.env.DB_NAME;

//AWS 관련 상수
exports.AWS_ACCESS_KEY_ID = process.env.AWS_ACCESS_KEY_ID;
exports.AWS_SECRET_ACCESS_KEY = process.env.AWS_SECRET_ACCESS_KEY;
exports.S3_BUCKET_NAME = 'mk-devmate-dev';
exports.AWS_REGION = 'ap-northeast-2';

// JWT 토큰 관련 상수
exports.JWT_SECRET = process.env.JWT_SECRET;
exports.JWT_EXPIRATION_TIME = '24h'; // 토큰 만료 시간 설정 (예: '1h', '24h', '7d' 등)

// 잡지 정보
exports.MAGAZINE_DUPLICATE = "MAGAZINE_DUPLICATE";
exports.MAGAZINE_INSERT = "MAGAZINE_INSERT";
exports.UPLOAD_TYPE_PDF = "pdf";
exports.UPLOAD_TYPE_XML = "xml";
exports.UPLOAD_TYPE_THUMB = "thumbnail";
exports.MAGAZINE_ID_CONFIRMED = "MAGAZINE_ID_CONFIRMED";
exports.MAGAZINE_ID_UNCONFIRMED = "MAGAZINE_ID_UNCONFIRMED";
exports.MAGAZINE_DELETED = "MAGAZINE_DELETED";
exports.MAGAZINE_PAGE_DELETED = "MAGAZINE_PAGE_DELETED";
exports.MAGAZINE_XML_DELETED = "MAGAZINE_XML_DELETED";
exports.MAGAZINE_THUMB_DELETED = "MAGAZINE_THUMB_DELETED";
exports.MAGAZINE_PAGE_SELECTED = "MAGAZINE_PAGE_SELECTED";
exports.MAGAZINE_XML_SELECTED = "MAGAZINE_XML_SELECTED";
exports.MAGAZINE_THUMB_SELECTED = "MAGAZINE_THUMB_SELECTED";

// 기타 상수들
exports.DEFAULT_ROLE = 'user';
exports.STATUS_OK = 200;
exports.STATUS_BAD_REQUEST = 400;
exports.STATUS_UNAUTHORIZED = 401;
exports.STATUS_FORBIDDEN = 403;
exports.STATUS_NOT_FOUND = 404;
exports.NEW_USER = 'NEW_USER';
exports.LOGIN = 'LOGIN';
exports.YES_MEMBERSHIP = 'YES_MEMBERSHIP';
exports.NO_MEMBERSHIP = 'NO_MEMBERSHIP';
exports.MEMBERSHIP_EXPR = 'MEMBERSHIP_EXPR';
exports.USER_SUBSCRIBE = 'subscribe';
exports.USER_TRIAL = 'trial';
exports.USE_YES = "USE_YES";
exports.USE_NO = "USE_NO";

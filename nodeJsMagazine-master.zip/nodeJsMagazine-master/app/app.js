// app.js

const express = require('express');
const bodyParser = require('body-parser');
const { sequelize } = require('./engine/db');
const userRoutes = require('./routes/userRoutes');
const magazineRoutes = require('./routes/magazinesRoutes');
const magazineAdminRoutes = require('./routes/magazinesAdminRoutes');
const uploadRoutes = require('./routes/uploadRoutes');
const logger = require('./config/log');

const app = express();
app.use(bodyParser.json());

// Use userRoutes
app.use('/api/user', userRoutes);
app.use('/api/magazine', magazineRoutes);
app.use('/api/magazine/admin', magazineAdminRoutes);
app.use('/api/upload', uploadRoutes);

// Start the server
const PORT = 3000;
sequelize.sync().then(() => {
  app.listen(PORT, () => {
    logger.info(`Server is running on port ${PORT}`);
  });
}).catch(error => {
  logger.error("Error while syncing database:", error);
});
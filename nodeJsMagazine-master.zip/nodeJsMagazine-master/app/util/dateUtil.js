"use strict";

const moment = require('moment');

// function getCurrentKoreaTime() {
//     // 현재 시간의 long 타입 타임스탬프를 가져옵니다.
//     const timestamp = new Date().getTime();
  
//     // moment 객체를 사용하여 타임스탬프를 한국 시간(KST)으로 변환합니다.
//     const koreaTime = moment(timestamp).utcOffset('+0900').format('YYYY-MM-DD HH:mm:ss');
//     conso
//     return koreaTime;
//   }


function getCurrentTimestampKtc() {
    return Math.floor(new Date().getTime() / 1000); // 한국 시간대로 변환한 초단위 timestamp
}
  
module.exports = { getCurrentTimestampKtc };
  
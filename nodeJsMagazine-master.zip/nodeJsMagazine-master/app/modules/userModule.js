// userModule.js

const userInfoModel = require('../models/userInfoModel');
const dateUtil = require('../util/dateUtil');
const jwt = require('jsonwebtoken');
const logger = require('../config/log');
const constants = require('../config/constants');

async function saveUserInfo(userInfo) {
    try {
        // Save user data to the database
        const existingUser = await userInfoModel.findOne({ where: { member_id: userInfo.member_id } });
        let resultCode;
        if(existingUser){
            existingUser.update({ last_login_date: dateUtil.getCurrentTimestampKtc() });

            // Generate JWT token for new user
            token = jwt.sign(
                { member_id: existingUser.member_id, role: existingUser.role },
                constants.JWT_SECRET,
                { expiresIn: constants.JWT_EXPIRATION_TIME } // 토큰의 유효기간을 1시간으로 설정
              );
            resultCode = constants.LOGIN;
            return {
                token,
                resultCode
            };
        } else {
            // Create new user
            const user = await userInfoModel.create({
                member_id: userInfo.member_id,
                username: userInfo.username,
                role: constants.DEFAULT_ROLE,
                registration_date: dateUtil.getCurrentTimestampKtc(),
                last_login_date: dateUtil.getCurrentTimestampKtc()
            });
            // Generate JWT token for new user
            token = jwt.sign({ member_id: user.member_id, role: user.role }, constants.JWT_SECRET);
            resultCode = constants.NEW_USER;
        }

        return {
            token,
            resultCode
        };
    } catch (error) {
        logger.error("Error while saving user:", error);
        throw error;
    }
};

function makeUserInfo(User) {
    const { mk_id, gubun, name, member_id, trial_start_date, trial_expire_date, start_date, expire_date, status } = User;

    // 한국 시간 기준 오늘 날짜 (현재 날짜)
    const today = new Date();
    const todayDate = today.toISOString().slice(0, 10).replace(/-/g, '');

    // if 문으로 조건 처리
    if (
        (gubun === constants.USER_SUBSCRIBE && start_date <= todayDate && todayDate <= expire_date) ||
        (gubun === constants.USER_TRIAL && trial_start_date <= todayDate && todayDate <= trial_expire_date)
    ) {
        if (status === 'Y') {
            return {
                member_id: member_id,
                username: name,
                resultCode: constants.YES_MEMBERSHIP
            };
        } else {
            return {
                member_id: member_id,
                username: name,
                resultCode: constants.NO_MEMBERSHIP
            };
        }
    } else {
        return {
            member_id: member_id,
            username: name,
            resultCode: constants.MEMBERSHIP_EXPR
        };
    }
};


async function getAllUsers() {
    try {
      const allUsers = await userInfoModel.findAll();
      return allUsers;
    } catch (error) {
      logger.error("Error while fetching all users:", error);
      throw error;
    }
  }

module.exports = { saveUserInfo, makeUserInfo,getAllUsers };

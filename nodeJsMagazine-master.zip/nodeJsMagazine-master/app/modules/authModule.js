// authModule.js

const jwt = require('jsonwebtoken');
const constants = require('../config/constants');

function authenticateToken(req, res, next) {
  const token = req.header('Authorization');
  if (!token) return res.sendStatus(constants.STATUS_UNAUTHORIZED);

  jwt.verify(token, constants.JWT_SECRET , (err, user) => {
    if (err) return res.sendStatus(constants.STATUS_FORBIDDEN);
    req.user = user;
    next();
  });
}


module.exports = { authenticateToken};

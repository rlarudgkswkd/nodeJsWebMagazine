// modules/awsS3Module.js
const fs = require('fs');
const { PDFDocument } = require('pdf-lib');
const AWS = require('aws-sdk');
const { AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, S3_BUCKET_NAME, AWS_REGION } = require('../config/constants');
const logger = require('../config/log');
const constants = require('../config/constants');

// AWS S3 설정
AWS.config.update({
  accessKeyId: AWS_ACCESS_KEY_ID,
  secretAccessKey: AWS_SECRET_ACCESS_KEY,
  region: AWS_REGION // S3 버킷의 리전에 맞게 설정
});

// 이미지, PDF, XML 파일을 S3 버킷에 업로드하는 함수
async function uploadFileToS3(file, fileType) {
  try {
    const s3 = new AWS.S3();
    const fileExtension = getFileExtension(file.originalname);
    const allowedFileTypes = ['image', 'pdf', 'xml'];

    if (!allowedFileTypes.includes(fileType)) {
      throw new Error("지원되지 않는 파일 형식입니다.");
    }

    const params = {
      Bucket: S3_BUCKET_NAME,
      Key: `${fileType}s/${Date.now()}_${file.originalname}`, // 업로드된 파일의 경로 (예: images/1627468172245_image.jpg)
      Body: file.buffer,
      ContentType: file.mimetype
    };

    // S3에 파일 업로드 요청
    const result = await s3.upload(params).promise();
    return {
      fileName: file.originalname ,
      location: result.Location// 업로드된 파일의 S3 경로를 반환
    };
  } catch (error) {
    logger.error("Error while uploading file to S3:", error);
    throw error;
  }
}

//분할 처리
async function uploadSplitFileToS3(fileData, fileName, fileNumber) {
  const s3 = new AWS.S3();
  const params = {
    Bucket: S3_BUCKET_NAME,
    Key: `pdfs/${fileName}/${fileNumber}.pdf`,
    Body: fileData
  };

  return new Promise((resolve, reject) => {
    s3.upload(params, (err, data) => {
      if (err) {
        reject(err);
      } else {
        resolve(data.Location);
      }
    });
  });
}

// 파일의 확장자를 추출하는 함수
function getFileExtension(filename) {
  const ext = filename.split('.').pop();
  return ext.toLowerCase();
}

// PDF 파일을 페이지별로 분리하고 각 페이지를 업로드하는 함수
async function splitAndUploadPDF(magazine_id,file, fileType) {
  try {
    let fileName = file.originalname;
    fileName = fileName.replace(/\.pdf$/, '');
    const pdfDoc = await PDFDocument.load(file.buffer);
    const pageCount = pdfDoc.getPageCount();

    const pageList = [];

    for (let i = 0; i < pageCount; i++) {
      const newPDF = await PDFDocument.create();
      const [copiedPage] = await newPDF.copyPages(pdfDoc, [i]);
      newPDF.addPage(copiedPage);

      const pdfBytes = await newPDF.save();

      // Convert pdfBytes (Uint8Array) to Buffer
      const pdfBuffer = Buffer.from(pdfBytes);

      // 페이지별로 업로드하는 함수 호출
      const uploadedUrl = await uploadSplitFileToS3(pdfBuffer, `${magazine_id}`,`${i + 1}`);
      pageList.push({
        magazine_page_id: i+1,
        magazine_page_path: uploadedUrl
      });
      // logger.info(`Uploaded page ${i + 1}: ${uploadedUrl}`);
    }

    // 페이지별 업로드가 완료되면 업로드된 페이지들의 URL을 반환
    const pageUrls = [];
    for (let i = 0; i < pageCount; i++) {
      const url = `${fileName}/${i + 1}.pdf`;
      pageUrls.push(url);
    }

    return {
      pageUrls,
      pageList
    };
  } catch (error) {
    throw new Error('Error while splitting and uploading PDF:', error);
  }
}

module.exports = { uploadFileToS3, splitAndUploadPDF };

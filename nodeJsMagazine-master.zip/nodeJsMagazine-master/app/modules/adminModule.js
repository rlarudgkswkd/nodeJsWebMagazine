
const { sequelize } = require('../engine/db');
const mgzMstrModel = require('../models/magazineMstrModel');
const magThumbModel = require('../models/magazineThumbModel');
const magPageModel = require('../models/magazinePageModel');
const magXmlModel = require('../models/magazineXmlModel');
const logger = require('../config/log');
const constants = require('../config/constants');

// Controller function to delete all magazine data based on magazine_id
async function deleteMagazineData(req, res) {
    try {
      const { magazine_id } = req.params;
  
      // Begin a transaction to ensure atomicity
      await sequelize.transaction(async (t) => {
        // Delete magazine data from related tables in reverse order to maintain referential integrity
            await magXmlModel.destroy({
            where: { magazine_id },
            transaction: t,
            });
    
            await magPageModel.destroy({
            where: { magazine_id },
            transaction: t,
            });
    
            await magThumbModel.destroy({
            where: { magazine_id },
            transaction: t,
            });
    
            await mgzMstrModel.destroy({
            where: { magazine_id },
            transaction: t,
            });
      });
  
      return res.json({
          status: constants.STATUS_OK,
          success: true,
          resultCode: constants.MAGAZINE_DELETED,
          result : {
              statusCode: null
          },
          message: "잡지 호가 정상적으로 삭제되었습니다."
      });
    } catch (error) {
        logger.error('Error while deleting magazine data:', error);
        res.status(500).json({ message: 'Server error' });
    }
  }

  // Controller function to delete magazine page data based on magazine_id
async function deleteMagazinePageData(req, res) {
  try {
    const { magazine_id } = req.params;

    await magPageModel.destroy({ where: { magazine_id } });
    return res.json({
      status: constants.STATUS_OK,
      success: true,
      resultCode: constants.MAGAZINE_PAGE_DELETED,
      result : {
          statusCode: null
      },
      message: "잡지 지면데이터가 정상적으로 삭제되었습니다."
    });
  } catch (error) {
    logger.error('Error while deleting magazine page data:', error);
    res.status(500).json({ message: 'Server error' });
  }
}

async function deleteMagazineXMLData(req, res) {
  try {
    const { magazine_id } = req.params;

    await magXmlModel.destroy({ where: { magazine_id } });
    return res.json({
      status: constants.STATUS_OK,
      success: true,
      resultCode: constants.MAGAZINE_XML_DELETED,
      result : {
          statusCode: null
      },
      message: "잡지 xml 데이터가 정상적으로 삭제되었습니다."
    });
  } catch (error) {
    logger.error('Error while deleting magazine XML data:', error);
    res.status(500).json({ message: 'Server error' });
  }
}

async function deleteMagazineThumbnailData(req, res) {
  try {
    const { magazine_id } = req.params;

    await magThumbModel.destroy({ where: { magazine_id } });
    return res.json({
      status: constants.STATUS_OK,
      success: true,
      resultCode: constants.MAGAZINE_THUMB_DELETED,
      result : {
          statusCode: null
      },
      message: "잡지 썸네일 데이터가 정상적으로 삭제되었습니다."
    });
  } catch (error) {
    logger.error('Error while deleting magazine thumbnail data:', error);
    res.status(500).json({ message: 'Server error' });
  }
}

async function getMagazinePageData(req, res) {
  try {
    const { magazine_id } = req.params;
    const magazineStatus = await checkMagazineIdExists(magazine_id);
    if(magazineStatus == "wrong_magazine_id"){
      return res.json({
        status: constants.STATUS_OK,
        success: true,
        resultCode: constants.MAGAZINE_ID_UNCONFIRMED,
        result : null,
        message: "없는 magazine_id 입니다."
      });
    }
    const magazinePageData = await magPageModel.findAll({ where: { magazine_id } });
    return res.json({
      status: constants.STATUS_OK,
      success: true,
      resultCode: constants.MAGAZINE_PAGE_SELECTED,
      result : {
        magazinePageData
      },
      message: "잡지 지면 데이터가 정상적으로 조회되었습니다."
    });
  } catch (error) {
    logger.error('Error while fetching magazine page data:', error);
    res.status(500).json({ message: 'Server error' });
  }
}

async function getMagazineXMLData(req, res) {
  try {
    const { magazine_id } = req.params;
    const magazineStatus = await checkMagazineIdExists(magazine_id);
    if(magazineStatus == "wrong_magazine_id"){
      return res.json({
        status: constants.STATUS_OK,
        success: true,
        resultCode: constants.MAGAZINE_ID_UNCONFIRMED,
        result : null,
        message: "없는 magazine_id 입니다."
      });
    }

    const magazineXMLData = await magXmlModel.findAll({ where: { magazine_id } });
    return res.json({
      status: constants.STATUS_OK,
      success: true,
      resultCode: constants.MAGAZINE_XML_SELECTED,
      result : {
        magazineXMLData
      },
      message: "잡지 xml 데이터가 정상적으로 조회되었습니다."
    });
  } catch (error) {
    logger.error('Error while fetching magazine XML data:', error);
    res.status(500).json({ message: 'Server error' });
  }
}

async function getMagazineThumbnailData(req, res) {
  try {
    const { magazine_id } = req.params;
    const magazineStatus = await checkMagazineIdExists(magazine_id);
    if(magazineStatus == "wrong_magazine_id"){
      return res.json({
        status: constants.STATUS_OK,
        success: true,
        resultCode: constants.MAGAZINE_ID_UNCONFIRMED,
        result : null,
        message: "없는 magazine_id 입니다."
      });
    }

    const magazineThumbnailData = await magThumbModel.findAll({ where: { magazine_id } });
    return res.json({
      status: constants.STATUS_OK,
      success: true,
      resultCode: constants.MAGAZINE_THUMB_SELECTED,
      result : {
        magazineThumbnailData
      },
      message: "잡지 썸네일 데이터가 정상적으로 조회되었습니다."
    });
  } catch (error) {
    logger.error('Error while fetching magazine thumb data:', error);
    res.status(500).json({ message: 'Server error' });
  }
}

async function checkMagazineIdExists(magazine_id) {
  const magazine = await mgzMstrModel.findOne({ where: { magazine_id } });
  if (!magazine) {
    return "wrong_magazine_id";  
  }
}
  
  module.exports = {
    deleteMagazineData,
    deleteMagazinePageData,
    deleteMagazineXMLData,
    deleteMagazineThumbnailData,
    getMagazinePageData,
    getMagazineXMLData,
    getMagazineThumbnailData
  };

const dateUtil = require('../util/dateUtil');
const constants = require('../config/constants');
const mgzMstrModel = require('../models/magazineMstrModel');
const magThumbModel = require('../models/magazineThumbModel');
const magPageModel = require('../models/magazinePageModel');
const magXmlModel = require('../models/magazineXmlModel');
const logger = require('../config/log');

// GET /magazine/{magazine_id}
async function checkMagazineById(req, res) {
    try {
      const { magazine_id } = req.params;
  
      // Check for duplicate magazine_id
      const existingMagazine = await mgzMstrModel.findOne({
        where: {
          magazine_id,
        },
      });
  
      if (existingMagazine) {
        return res.json({
            status: constants.STATUS_OK,
            success: true,
            resultCode: constants.MAGAZINE_ID_UNCONFIRMED,
            result : {
                statusCode: constants.USE_NO
            },
            message: "사용 불가능한 magazine_id입니다."
        });
      }
  
      // If the magazine_id is not found, return a success response
      return res.json({
        status: constants.STATUS_OK,
        success: true,
        resultCode: constants.MAGAZINE_ID_CONFIRMED,
        result : {
            statusCode: constants.USE_YES
        },
        message: "사용 가능한 magazine_id입니다."
    });

    } catch (error) {
      console.error('Error while checking duplicate magazine_id:', error);
      res.status(500).json({ message: '서버 오류' });
    }
  }

// T_MGZ_MSTR 테이블에 잡지 정보 삽입
async function insertMagazineMstr(magazine_id, magazine_name, issue_date) {
    try {
        // Check for duplicate magazine_id
        const existingMagazine = await mgzMstrModel.findOne({        
            raw: true, 
            where: {
                magazine_id,
            },
        });
    
        if (existingMagazine) {
            throw new Error('이미 해당 잡지 정보가 존재합니다.');
        }

        const magazine = await mgzMstrModel.create({
            magazine_id,
            magazine_name,
            issue_date,
            registration_date: dateUtil.getCurrentTimestampKtc(),
        });
  
        return {
            statusCode: constants.MAGAZINE_INSERT,
            magazine_id
        };
    } catch (error) {
        // throw new Error('Error while inserting magazine information:', error);
        return {
            statusCode: constants.MAGAZINE_DUPLICATE,
        }
    }
  }

// T_MGZ_THUMB 테이블에 잡지 정보 삽입
async function insertMagazineThumb(magazine_id, thumb_image_name, thumb_image_path) {
    try {

        const thumbNail = await magThumbModel.create({
            magazine_id,
            thumbnail_id: 1, //thumbnail 단일로 지정으로 우선 하드코딩
            thumb_image_name,
            thumb_image_path,
            registration_date: dateUtil.getCurrentTimestampKtc(),
        });
  
        return thumbNail.thumbnail_id;
    } catch (error) {
        throw new Error('Error while inserting thumbnail information:', error);
        // return {
        //     statusCode: constants.MAGAZINE_DUPLICATE,
        // }
    }
  }

// T_MGZ_PAGE 테이블에 잡지 정보 삽입
async function insertMagazinePage(magazine_id, pageList) {
    try {
        await Promise.all(
            pageList.map(async (page) => {
              const { magazine_page_id, magazine_page_path } = page;
              const magazinePage = await magPageModel.create({
                magazine_id: magazine_id,
                magazine_page_id: magazine_page_id,
                magazine_page_path: magazine_page_path,
                registration_date: dateUtil.getCurrentTimestampKtc(),
              });
          
              return {
                magazine_page_id: magazinePage.magazine_id,
                magazine_page_path: magazinePage.magazine_page_path,
              };
            })
          );
  
        return 0;
    } catch (error) {
        throw new Error('Error while inserting thumbnail information:', error);
        // return {
        //     statusCode: constants.MAGAZINE_DUPLICATE,
        // }
    }
  }

// T_MGZ_XML 테이블에 잡지 정보 삽입
async function insertMagazineXml(magazine_id, xml_name, xml_path) {
    try {

        const xml = await magXmlModel.create({
            magazine_id,
            xml_id: 1, //thumbnail 단일로 지정으로 우선 하드코딩
            xml_name,
            xml_path,
            registration_date: dateUtil.getCurrentTimestampKtc(),
        });
  
        return xml.xml_id;
    } catch (error) {
        throw new Error('Error while inserting thumbnail information:', error);
        // return {
        //     statusCode: constants.MAGAZINE_DUPLICATE,
        // }
    }
  }

  module.exports = {
    insertMagazineMstr,
    insertMagazineThumb,
    insertMagazinePage,
    insertMagazineXml,
    checkMagazineById
  };
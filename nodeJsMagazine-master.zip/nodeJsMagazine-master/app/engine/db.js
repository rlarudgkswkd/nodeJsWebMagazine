// db.js

const constants = require('../config/constants');
const { Sequelize, DataTypes } = require('sequelize');
const sequelize = new Sequelize(constants.DB_NAME, constants.DB_USER, constants.DB_PASSWORD, {
  host: constants.DB_HOST,
  dialect: 'mariadb'
});

module.exports = { sequelize,DataTypes };

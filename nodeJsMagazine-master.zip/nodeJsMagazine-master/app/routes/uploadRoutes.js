// routes/uploadRoutes.js


const express = require('express');
const multer = require('multer');
const { uploadFileToS3, splitAndUploadPDF } = require('../modules/awsS3Module');
const { authenticateToken } = require('../modules/authModule');
const magazineUploadModule = require('../modules/magazineUploadModule');
const constants = require('../config/constants');

const logger = require('../config/log');

const router = express.Router();
const upload = multer(); // Multer 미들웨어 설정

// GET /magazine/{magazine_id}
router.get('/magazine/:magazine_id', authenticateToken, magazineUploadModule.checkMagazineById);

router.post('/magazine', authenticateToken, upload.fields([
  { name: 'magazine_thumb_nail', maxCount: 1 },
  { name: 'magazine_pdf', maxCount: 1 },
  { name: 'magazine_xml', maxCount: 1 }
]), async (req, res) => {

  try {
    // Formdata에서 잡지 정보 추출
    const { magazine_id, magazine_name, issue_date } = req.body;

    // T_MGZ_MSTR 테이블에 잡지 정보 삽입
    const insertedMagazineId = await magazineUploadModule.insertMagazineMstr(magazine_id, magazine_name, issue_date);

    if(insertedMagazineId.statusCode === constants.MAGAZINE_DUPLICATE){
      res.status(500).json({ message: "중복된 magazine_id" });
    } else {
      // 파일들 업로드 처리
      const thumbNailFile = req.files['magazine_thumb_nail'][0];
      const pdfFile = req.files['magazine_pdf'][0];
      const xmlFile = req.files['magazine_xml'][0];
      
      // 각 파일들을 S3에 업로드
      const thumbNailResult = await uploadFileToS3(thumbNailFile, 'image');
      const thumbNailId = await magazineUploadModule.insertMagazineThumb(magazine_id,thumbNailResult.fileName,thumbNailResult.location);

      // const pdfUrl = await uploadFileToS3(pdfFile, 'pdf');
      const pdfResult = await splitAndUploadPDF(magazine_id,pdfFile, 'pdf'); // PDF를 페이지별로 분리하여 업로드
      const pdfPage = await magazineUploadModule.insertMagazinePage(magazine_id,pdfResult.pageList);
      const xmlResult = await uploadFileToS3(xmlFile, 'xml');
      const xmlId = await magazineUploadModule.insertMagazineXml(magazine_id,xmlResult.fileName,xmlResult.location);

      return res.json({
        status: constants.STATUS_OK,
        success: true,
        resultCode: "MAGAZINE_REGISTERED",
        result : {
            magazine_id: insertedMagazineId,
            magazine_name,
            issue_date,
            // thumbNailResult,
            // thumbNailId,
            // pdfResult,
            // pdfPage,
            // xmlResult
          },
        message: "잡지 등록이 성공적으로 완료되었습니다."
      }); 
    }

  } catch (error) {
    logger.error("Error while uploading magazine:", error);
    res.status(500).json({ message: "서버 오류" });
  }
});

// 이미지를 업로드하는 라우트
router.post('/image', authenticateToken, multer().single('image'), async (req, res) => {
  try {
    const file = req.file;
    if (!file) {
      res.status(400).json({ message: "이미지 파일이 필요합니다." });
      return;
    }

    const imageUrl = await uploadFileToS3(file, 'image');
    res.json({ imageUrl });
  } catch (error) {
    logger.error("Error while uploading image:", error);
    res.status(500).json({ message: "서버 오류" });
  }
});

// PDF를 업로드하는 라우트
router.post('/pdf', authenticateToken, multer().single('pdf'), async (req, res) => {
  try {
    const file = req.file;
    if (!file) {
      res.status(400).json({ message: "PDF 파일이 필요합니다." });
      return;
    }

    const pdfUrl = await uploadFileToS3(file, 'pdf');
    res.json({ pdfUrl });
  } catch (error) {
    logger.error("Error while uploading PDF:", error);
    res.status(500).json({ message: "서버 오류" });
  }
});

// PDF를 페이지별로 나누어 업로드하는 라우트
router.post('/pdf/split', authenticateToken, multer().single('pdf'), async (req, res) => {
  try {
    const file = req.file;
    if (!file) {
      res.status(400).json({ message: "PDF 파일이 필요합니다." });
      return;
    }

    // 전체 PDF 파일을 페이지별로 나누어 업로드하는 함수 호출
    const pdfUrls = await splitAndUploadPDF(file, 'pdf');
    res.json({
      pdfUrls,
      message: "PDF 파일이 페이지별로 업로드되었습니다."
    });
  } catch (error) {
    logger.error("Error while uploading PDF:", error);
    res.status(500).json({ message: "서버 오류" });
  }
});

// XML을 업로드하는 라우트
router.post('/xml', authenticateToken, multer().single('xml'), async (req, res) => {
  try {
    const file = req.file;
    if (!file) {
      res.status(400).json({ message: "XML 파일이 필요합니다." });
      return;
    }

    const xmlUrl = await uploadFileToS3(file, 'xml');
    res.json({ xmlUrl });
  } catch (error) {
    logger.error("Error while uploading XML:", error);
    res.status(500).json({ message: "서버 오류" });
  }
});

module.exports = router;

// routes/magazineRoutes.js

const express = require('express');
const { authenticateToken } = require('../modules/authModule');
const adminModule = require('../modules/adminModule');

const router = express.Router();

router.post('/list', authenticateToken, (req, res) => {
  res.send("관리자 잡지 리스트임");
});

// DELETE route for deleting all magazine data based on magazine_id
router.delete('/:magazine_id', authenticateToken, adminModule.deleteMagazineData);
router.delete('/page/:magazine_id', authenticateToken, adminModule.deleteMagazinePageData);
router.delete('/xml/:magazine_id', authenticateToken, adminModule.deleteMagazineXMLData);
router.delete('/thumb/:magazine_id', authenticateToken, adminModule.deleteMagazineThumbnailData);
router.get('/page/:magazine_id', authenticateToken, adminModule.getMagazinePageData);
router.get('/xml/:magazine_id', authenticateToken, adminModule.getMagazineXMLData);
router.get('/thumb/:magazine_id', authenticateToken, adminModule.getMagazineThumbnailData);

module.exports = router;

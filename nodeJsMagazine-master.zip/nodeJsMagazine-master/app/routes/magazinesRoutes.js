// routes/magazineRoutes.js

const express = require('express');
const { authenticateToken } = require('../modules/authModule');
const mgzMstrModel = require('../models/magazineMstrModel');
const mgzThumbModel = require('../models/magazineThumbModel');
const mgzPageModel = require('../models/magazinePageModel');
const mgzXmlModel = require('../models/magazineXmlModel');
const logger = require('../config/log');
const constants = require('../config/constants');

const router = express.Router();

//전체 잡지 리스트 조회
router.get('/list', authenticateToken , async (req, res) => {
  try {
    const magazines = await mgzMstrModel.findAll({
      attributes: ['magazine_id', 'magazine_name', 'issue_date', 'registration_date'],
      // include: [
      //   {
      //     model: mgzThumbModel,
      //     attributes: ['thumbnail_id', 'thumb_image_path'],
      //   },
      //   {
      //     model: mgzPageModel,
      //     attributes: ['magazine_page_id', 'magazine_page_path'],
      //   },
      //   {
      //     model: mgzXmlModel,
      //     attributes: ['xml_id', 'xml_path'],
      //   },
      // ],
    });

    return res.json({
      status: constants.STATUS_OK,
      success: true,
      resultCode: "MAGAZINE_LIST",
      result : {
          magazines
        },
      message: "전체 잡지 리스트 조회"
    }); 
  } catch (error) {
    logger.error("Error while fetching magazine list:", error);
    res.status(500).json({ message: "서버 오류" });
  }
});

// HTTP POST method to get magazine detail with page and xml information
router.get('/detail/:magazine_id', async (req, res) => {
  try {
    const { magazine_id } = req.params;

    const magazine = await mgzMstrModel.findOne({
      where: { magazine_id },
      include: [
        {
          model: mgzPageModel,
          attributes: ['magazine_page_id', 'magazine_page_path'],
        },
        {
          model: mgzXmlModel,
          attributes: ['xml_id', 'xml_name', 'xml_path'],
        },
      ],
    });

    if (!magazine) {
      res.status(404).json({ message: "지면 정보를 찾을 수 없습니다." });
      return;
    }

    return res.json({
      status: constants.STATUS_OK,
      success: true,
      resultCode: "MAGAZINE_DETAIL",
      result : {
          magazine
        },
      message: "잡지 상세 조회"
    }); 
  } catch (error) {
    logger.error("Error while fetching magazine detail:", error);
    res.status(500).json({ message: "서버 오류" });
  }
});

module.exports = router;

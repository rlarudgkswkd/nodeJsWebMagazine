// routes/userRoutes.js

const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');
const { authenticateToken } = require('../modules/authModule');

router.post('/', userController.createUser);
router.get('/list', authenticateToken, userController.getAllUsers);

module.exports = router;

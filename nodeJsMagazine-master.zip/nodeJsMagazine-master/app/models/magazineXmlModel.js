const { sequelize,DataTypes } = require('../engine/db');

const magXmlModel = sequelize.define('T_MGZ_XML', {
  magazine_id: {
    type: DataTypes.INTEGER.UNSIGNED,
    primaryKey: true,
    allowNull: false,
  },
  xml_id: {
    type: DataTypes.INTEGER.UNSIGNED,
    primaryKey: true,
    allowNull: false,
  },
  xml_name: {
    type: DataTypes.STRING(100),
  },
  xml_path: {
    type: DataTypes.STRING,
  },
  registration_date: {
    type: DataTypes.BIGINT(50),
  },
}, {
  timestamps: false, // timestamps 필드를 사용하지 않도록 설정
  tableName: 'T_MGZ_XML', // 테이블명 지정 (기본적으로 모델명의 복수형)
});

module.exports = magXmlModel;

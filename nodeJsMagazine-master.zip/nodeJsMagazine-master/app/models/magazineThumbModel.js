const { sequelize,DataTypes } = require('../engine/db');

const magThumbModel = sequelize.define('T_MGZ_THUMB', {
  magazine_id: {
    type: DataTypes.INTEGER.UNSIGNED,
    primaryKey: true,
    allowNull: false,
  },
  thumbnail_id: {
    type: DataTypes.INTEGER.UNSIGNED,
    primaryKey: true,
    allowNull: false,
    autoIncrement: true,
  },
  thumb_image_name: {
    type: DataTypes.STRING(100),
    allowNull: true,
  },
  thumb_image_path: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  registration_date: {
    type: DataTypes.BIGINT(50),
    allowNull: true,
  },
}, {
  timestamps: false, // timestamps 필드를 사용하지 않도록 설정
  tableName: 'T_MGZ_THUMB', // 테이블명 지정 (기본적으로 모델명의 복수형)
});

module.exports = magThumbModel;

// models/userModel.js

const { sequelize,DataTypes } = require('../engine/db');

// 테이블 모델 정의
const userInfoModel = sequelize.define('T_USER_INFO', {
    member_id: {
      type: DataTypes.BIGINT(20).UNSIGNED,
      primaryKey: true,
      allowNull: false,
    },
    username: {
      type: DataTypes.STRING(50),
      allowNull: true,
    },
    email: {
      type: DataTypes.STRING(100),
      allowNull: true,
    },
    role: {
      type: DataTypes.STRING(20),
      allowNull: true,
    },
    registration_date: {
      type: DataTypes.BIGINT(50),
      allowNull: true,
    },
    last_login_date: {
      type: DataTypes.BIGINT(50),
      allowNull: true,
    },
  }, {
    tableName: 'T_USER_INFO',
    timestamps: false,
  });

module.exports = userInfoModel;

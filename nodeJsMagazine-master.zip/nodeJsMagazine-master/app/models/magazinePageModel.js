const { sequelize,DataTypes } = require('../engine/db');

const magPageModel = sequelize.define('T_MGZ_PAGE', {
  magazine_id: {
    type: DataTypes.INTEGER.UNSIGNED,
    primaryKey: true,
    allowNull: false,
  },
  magazine_page_id: {
    type: DataTypes.INTEGER.UNSIGNED,
    primaryKey: true,
    allowNull: false,
  },
  content: {
    type: DataTypes.TEXT,
  },
  magazine_page_path: {
    type: DataTypes.STRING(200),
  },
  page_number: {
    type: DataTypes.INTEGER.UNSIGNED,
  },
  registration_date: {
    type: DataTypes.BIGINT(50),
  },
}, {
  timestamps: false, // timestamps 필드를 사용하지 않도록 설정
  tableName: 'T_MGZ_PAGE', // 테이블명 지정 (기본적으로 모델명의 복수형)
});

module.exports = magPageModel;

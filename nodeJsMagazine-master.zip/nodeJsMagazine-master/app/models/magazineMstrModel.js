const { sequelize,DataTypes } = require('../engine/db');

const magMstrModel = sequelize.define('T_MGZ_MSTR', {
  magazine_id: {
    type: DataTypes.BIGINT(20).UNSIGNED,
    primaryKey: true,
    allowNull: false,
  },
  issue_date: {
    type: DataTypes.STRING,
    allowNull: true
  },
  magazine_number: {
    type: DataTypes.STRING,
    allowNull: true
  },
  magazine_name: {
    type: DataTypes.STRING,
    allowNull: true
  },
  subtitle: {
    type: DataTypes.STRING,
    allowNull: true
  },
  registration_date: {
    type: DataTypes.BIGINT,
    allowNull: true
  }
}, {
  tableName: 'T_MGZ_MSTR',
  timestamps: false,
});

// Define the association between T_MGZ_THUMB and T_MGZ_MSTR
magMstrModel.hasOne(require('./magazineThumbModel'), { foreignKey: 'magazine_id' });
// Define association with T_MGZ_PAGE
magMstrModel.hasMany(require('./magazinePageModel'), { foreignKey: 'magazine_id', sourceKey: 'magazine_id' });
// Define association with T_MGZ_XML
magMstrModel.hasMany(require('./magazineXmlModel'), { foreignKey: 'magazine_id', sourceKey: 'magazine_id' });

module.exports = magMstrModel;

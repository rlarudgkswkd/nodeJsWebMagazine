// controllers/userController.js

const UserInfo = require('../modules/userModule');
const constants = require('../config/constants');
const logger = require('../config/log');

async function createUser(req, res) {
  try {
    const { mk_id, gubun, name, member_id, trial_start_date, trial_expire_date, start_date, expire_date, status } = req.body;

    const user = {
        mk_id, gubun, name, member_id, trial_start_date, trial_expire_date, start_date, expire_date, status
    };
    
    const userInfo = UserInfo.makeUserInfo(user);
    
    if(userInfo.resultCode === constants.YES_MEMBERSHIP){
        const saveUserInfoResult = await UserInfo.saveUserInfo(userInfo);
        
        if(saveUserInfoResult.resultCode === constants.LOGIN){
            // Return success response
            return res.json({
                status: constants.STATUS_OK,
                success: true,
                resultCode: saveUserInfoResult.resultCode,
                result : saveUserInfoResult,
                message: "User 로그인이 성공적으로 완료되었습니다."
            });
        } else{
            // Return success response
            return res.json({
                status: constants.STATUS_OK,
                success: true,
                resultCode: saveUserInfoResult.resultCode,
                result : saveUserInfoResult,
                message: "User 등록이 성공적으로 완료되었습니다."
            });
        }
        
    } else if(userInfo.resultCode === constants.NO_MEMBERSHIP){
        return res.json({
            status: constants.STATUS_OK,
            success: false,
            resultCode: constants.NO_MEMBERSHIP,
            result:"",
            message: "해당 멤버십은 이용 불가능합니다."
        });    
    } else if(userInfo.resultCode === constants.MEMBERSHIP_EXPR){
        return res.json({
            status: 200,
            success: false,
            resultCode: constants.MEMBERSHIP_EXPR,
            result:"",
            message: "현재 멤버십 기간이 아닙니다."
          });
    } else {
        //TODO 추후 예외처리 필요
        return res.json({
            status: constants.STATUS_OK,
            success: false,
            resultCode: "ANOMALY_CONTACT",
            result:"",
            message: "비정상적 접근."
          });
    }
      

  } catch (error) {
    logger.error("Error while saving user:", error);
    // Return failure response
    return res.json({
      status: constants.STATUS_OK,
      success: false,
      resultCode: "ANOMALY_CONTACT",
      result:"",
      message: "유효하지 않은 데이터입니다."
    });
  }
}

async function getAllUsers(req,res) {
    if (req.user.role === "admin") {
        // 사용자가 관리자인 경우에만 getAllUsersController로 이동
        const getAllUsers = await UserInfo.getAllUsers();
        return res.send(getAllUsers);
      } else {
        res.status(403).json({
          status: 403,
          success: false,
          message: "권한이 없습니다."
        });
      }

  }
  

module.exports = {
  createUser,
  getAllUsers
};
